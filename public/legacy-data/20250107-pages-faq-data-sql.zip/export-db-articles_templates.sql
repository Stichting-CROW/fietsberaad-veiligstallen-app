USE `veiligstallen`;
SET FOREIGN_KEY_CHECKS = 0;
-- MySQL dump 10.13  Distrib 8.0.44, for Linux (x86_64)
--
-- Host: 10.132.29.69    Database: veiligstallen
-- ------------------------------------------------------
-- Server version	8.0.42-azure

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Dumping data for table `articles_templates`
--

LOCK TABLES `articles_templates` WRITE;
/*!40000 ALTER TABLE `articles_templates` DISABLE KEYS */;
INSERT INTO `articles_templates` VALUES ('00D16C37-4201-4446-93E796A50207974A','0','Fietskluizen','Fietskluizen',NULL,NULL,NULL,NULL,NULL,NULL,26,NULL,NULL,'1','main','0','1','fietskluizen'),('017ABA22-1041-4423-AEA64B4DC59FD83C','0','Stop reservering','Reservering be&euml;indigen',NULL,NULL,NULL,NULL,NULL,NULL,99,NULL,NULL,'1',NULL,'0','1','fietskluizen'),('0D6438FF-9C20-DBA1-25C981F410BD4FC3','0','Tekst_links',NULL,NULL,NULL,NULL,NULL,NULL,NULL,90,NULL,NULL,'1',NULL,'0','1','veiligstallen'),('0D73EA97-FAD7-0514-0F1C8D1B8AADCFB4','0','Tekst_rechts',NULL,NULL,NULL,NULL,NULL,NULL,NULL,90,NULL,NULL,'1',NULL,'0','1','veiligstallen'),('1011E23E-FA20-4385-B3094B5249A0988C','0','fietstrommels','Fietstrommels',NULL,NULL,NULL,NULL,NULL,NULL,24,NULL,NULL,'1','main','0','1','veiligstallen'),('14304793-FC33-12D9-FF664AB4238FCEA7','0','Login',NULL,NULL,NULL,NULL,NULL,NULL,NULL,90,NULL,NULL,'1',NULL,'0','1','veiligstallen'),('247C0778-D3E4-A5E9-2B292C4F9E61C400','0','checkoutkluis',NULL,NULL,NULL,NULL,NULL,NULL,NULL,99,NULL,NULL,'1',NULL,'0','1','fietskluizen'),('28042209-92DF-F46F-5A84D2E3BA391C71','0','buurtstalling_abonnement','Abonnement buurtstalling',NULL,NULL,NULL,NULL,NULL,NULL,85,NULL,NULL,'1',NULL,'0','1','veiligstallen'),('385EF48F-A320-331C-CFBFE3A93EE9C971','0','Reserveren','Fietskluis reserveren',NULL,NULL,NULL,NULL,NULL,NULL,85,NULL,NULL,'1',NULL,'0','1','fietskluizen'),('387A617F-D38A-3B3C-09670356DF8B6B90','0','editReservering','Reservering wijzigen',NULL,NULL,NULL,NULL,NULL,NULL,85,NULL,NULL,'1',NULL,'0','1','fietskluizen'),('3D9ADE6C-A1DC-6E99-917EA5C430277D7A','0','Home','Kaart','','<p>Templatetekst Home</p>',NULL,NULL,NULL,'',10,NULL,NULL,'1','main','1','1','veiligstallen'),('3D9BBA9F-B9E3-E50D-4F0471F49410E6D1','0','Stallingen','','','<p>Templatetekst Fietsenstallingen</p>',NULL,NULL,NULL,'',22,NULL,NULL,'1','main','1','1','veiligstallen'),('3D9C66FB-0C1D-1DD7-78FEDB89A2C40126','0','Prijzenpot','Fiets-en-win','','<p>Templatetekst Trekkingen en Prijzenpot</p>',NULL,NULL,NULL,'',30,NULL,NULL,'1','main','1','1','fietsenwin'),('3D9D05D0-C4E6-F071-651334B4BD12661B','0','FAQ',NULL,'','<p>Templatetekst Veel Gestelde Vragen</p>',NULL,NULL,NULL,'',40,NULL,NULL,'1','main','1','1','veiligstallen'),('3D9D85BD-ECD6-568A-C4A916491D388C12','0','Fietsen_in','Fietsen in','','<p>Templatetekst Fietsen in Gemeente...</p>',NULL,NULL,NULL,'',50,NULL,NULL,'0','main','1','1','veiligstallen'),('3D9F05B9-B387-A13D-34DD7E2DE4EE3084','0','MyPage','Mijn VeiligStallen','','<p>Templatetekst Mijn pagina voor deelnemers</p>',NULL,NULL,NULL,'',70,NULL,NULL,'1',NULL,'1','1','veiligstallen'),('67863F67-33ED-4A8D-80F658139CEAF4C3','0','Buurtstallingen','',NULL,NULL,NULL,NULL,NULL,NULL,22,NULL,NULL,'1','main','0','1','veiligstallen'),('73E0B442-DFC8-9702-D587CA20584FBDF1','0','Nieuwe Fietsenstalling',NULL,NULL,NULL,NULL,NULL,NULL,NULL,90,NULL,NULL,'1',NULL,'0','1','veiligstallen'),('D514840F-CDE6-950C-825C32F91736C4C9','0','Algemene Voorwaarden',NULL,NULL,'<p>Templatetekst Algemene Voorwaarden</p>',NULL,NULL,NULL,NULL,80,NULL,NULL,'1',NULL,'0','1','veiligstallen'),('E2DB5948-F905-A183-0AC6DE2197A31398','0','Tips',NULL,NULL,NULL,NULL,NULL,NULL,NULL,90,NULL,NULL,'1','main','0','1','veiligstallen'),('E2E17D79-E73A-0F30-02A9DDFE4FD0623B','0','Registreren',NULL,NULL,NULL,NULL,NULL,NULL,NULL,90,NULL,NULL,'1','main','0','1','veiligstallen'),('E5A879D9-CFAB-402B-A3F0F79A101FB0D7','0','KoppelFiets','Mijn fiets staat in een kluis',NULL,NULL,NULL,NULL,NULL,NULL,85,NULL,NULL,'1',NULL,'0','1','fietskluizen'),('E7473C2C-FCD9-1FB2-D143A75047CBB0E2','0','Abonnement','Abonnement',NULL,NULL,NULL,NULL,NULL,NULL,85,NULL,NULL,'1',NULL,'0','1','veiligstallen'),('E7A27443-86A1-4BD0-BEB9CF3C8C9888DB','0','Reserveren','Fietskluis reserveren',NULL,NULL,NULL,NULL,NULL,NULL,99,NULL,NULL,'1',NULL,'0','1','fietskluizen'),('E7A27443-86A1-4BD0-BEB9CF3C8C9888DC','0','MijnGegevens','Mijn gegevens',NULL,NULL,NULL,NULL,NULL,NULL,120,NULL,NULL,'1',NULL,'0','1','veiligstallen'),('E7A27443-86A1-4BD0-BEB9CF3C8C9888DD','0','Winkansen','Winkansen',NULL,NULL,NULL,NULL,NULL,NULL,110,NULL,NULL,'1',NULL,'0','1','fietsenwin'),('E7A27443-86A1-4BD0-BEB9CF3C8C9888DE','0','Transacties','Transacties',NULL,NULL,NULL,NULL,NULL,NULL,100,NULL,NULL,'1',NULL,'0','1','fms'),('E7A27443-86A1-4BD0-BEB9CF3C8C9888DF','0','Stallingstegoed','Stallingstegoed opwaarderen',NULL,NULL,NULL,NULL,NULL,NULL,90,NULL,NULL,'1',NULL,'0','1','fms'),('EBD1A50C-0A6B-4018-8AF4D2BBE086138D','0','huurKluis','Kluis huren',NULL,NULL,NULL,NULL,NULL,NULL,99,NULL,NULL,'1',NULL,'0','1','fietskluizen');
/*!40000 ALTER TABLE `articles_templates` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-01-07 21:38:22
SET FOREIGN_KEY_CHECKS = 1;
